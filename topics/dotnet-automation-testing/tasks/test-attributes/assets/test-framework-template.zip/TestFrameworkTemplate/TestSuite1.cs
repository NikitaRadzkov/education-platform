﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestFrameworkTemplate
{
    class TestSuite1
    {
      
        public void Test11()
        {
            Thread.Sleep(3000);
        }

        public void Test12()
        {
            Thread.Sleep(3000);
        }

        public void Test13()
        {
            Thread.Sleep(3000);
        }
      
        public void Test14()
        {
            Thread.Sleep(3000);
        }
      
    }
}
