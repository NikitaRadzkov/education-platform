﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestFrameworkTemplate
{
    class TestSuite2
    {
        public void Test21()
        {
            Thread.Sleep(3000);
        }

        public void Test22()
        {
            Thread.Sleep(3000);
        }

        public void Test23()
        {
            Thread.Sleep(3000);
        }

        public void Test24()
        {
            Thread.Sleep(3000);
        } 
    }
}
