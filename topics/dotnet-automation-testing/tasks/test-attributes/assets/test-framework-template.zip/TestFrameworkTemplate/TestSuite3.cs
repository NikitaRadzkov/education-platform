﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace TestFrameworkTemplate
{
    class TestSuite3
    {
        public void Test31()
        {
            Thread.Sleep(3000);
            // Introduce assertion failure
        }

        public void Test32()
        {
            Thread.Sleep(3000);
            throw new Exception("Exception thrown"); // Throw exception
        }

        
        public void Test33()
        {
           Thread.Sleep(1000); // Wait less than MaxTime threshold
                    
        }

    }
}
